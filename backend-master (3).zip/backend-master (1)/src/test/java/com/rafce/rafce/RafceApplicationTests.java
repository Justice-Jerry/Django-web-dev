package com.rafce.rafce;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RafceApplicationTests {

	@Test
	void contextLoads() {
	}

}

package com.rafce.rafce.model;

public enum ERole {
    ROLE_US,
    ROLE_PI,
    ROLE_ADMIN,

    ROLE_EDITOR,

}

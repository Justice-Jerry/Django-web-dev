package com.rafce.rafce.repository;

import com.rafce.rafce.model.Password;
import org.springframework.data.mongodb.repository.MongoRepository;

public interface PasswordResetRepository extends MongoRepository<Password, Long> {

}

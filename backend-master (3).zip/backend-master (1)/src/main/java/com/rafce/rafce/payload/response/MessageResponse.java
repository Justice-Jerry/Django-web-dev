package com.rafce.rafce.payload.response;


import lombok.*;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class MessageResponse {

    private String message;

}

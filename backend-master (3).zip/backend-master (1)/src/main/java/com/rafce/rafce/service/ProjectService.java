package com.rafce.rafce.service;

import com.rafce.rafce.model.Invitation;
import com.rafce.rafce.model.Password;
import com.rafce.rafce.model.Profile;
import com.rafce.rafce.model.Project;
import com.rafce.rafce.payload.response.AllCollaboratorsResponse;
import com.rafce.rafce.repository.InvitationRepository;
import com.rafce.rafce.repository.PasswordResetRepository;
import com.rafce.rafce.repository.ProjectRepository;
import lombok.AllArgsConstructor;
import lombok.NoArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;


@Service
@AllArgsConstructor
@NoArgsConstructor
public class ProjectService {
    @Autowired
    InvitationRepository invitationRepository;

    @Autowired
    ProjectRepository projectRepository;

    @Autowired
    PasswordResetRepository passwordResetRepository;

    @Autowired
    JavaMailSender javaMailSender;
    public Project createProject(Project project){
//      Optional<Profile> optionalProfile = profileRepository.findByUsername(admin);
//      Profile profile = optionalProfile.orElseThrow();
        LocalDate date = LocalDate.now();
//      project.setCreator(profile);
        project.setCreatedAt(date);

        return projectRepository.save(project);
    }

    public void sendEmail(String subject, String email, String message){
        SimpleMailMessage mailMessage = new SimpleMailMessage();
        mailMessage.setTo(email);
        mailMessage.setSubject(subject);
        mailMessage.setFrom("RAFCEGH");
        mailMessage.setText(message);


        javaMailSender.send(mailMessage);
    }

    public List<Project> getProjectCreatedByPi(Profile creator){
        return projectRepository.findByCreator(creator);
    }
    public String sendInvite(Project project, String email, String firstname, String lastname, String code, String organization){
        Invitation invite = new Invitation();
        invite.setFirstName(firstname);
        invite.setLastName(lastname);
        invite.setEmail(email);
        invite.setProjectCode(code);
        invite.setOrganization(organization);
        invite.setStatus("PENDING");
        invitationRepository.save(invite);


        String subject = "You are invited to collaborate on " + project.getName();
        String message = "Dear " + invite.getFirstName() + " " + invite.getLastName() + ",\n\n"
                + "You have been invited to collaborate on the project: " + project.getName() + ".\n"
                + "On accept, you will be prompted to enter some additional details " +
                "to be used to create your user account \n\n"
                + "Please click on the link below to accept the invitation:\n"
                + "http://localhost:3000/accept/" + invite.getId() + "\n\n"
                + "Best regards,\n"
                + "Project Team";
            sendEmail(subject, invite.getEmail(), message);
            return invite.getId();
    }

    public String sendInvite(Project project, String email, String username, String code){
        Invitation invite = new Invitation();
        invite.setEmail(email);
        invite.setUsername(username);
        invite.setProjectCode(code);
        invite.setStatus("PENDING");
        invitationRepository.save(invite);


        String subject = "You are invited to collaborate on " + project.getName();
        String message = "Dear " + invite.getUsername() + ",\n\n"
                + "You have been invited to collaborate on the project: " + project.getName() + ".\n"
                + "Please click on the link below to accept the invitation:\n"
                + "http://localhost:3000/user-accept/" + invite.getId() + "\n\n"
                + "Best regards,\n"
                + "Project Team";
        sendEmail(subject, invite.getEmail(), message);
        return invite.getId();
    }
    public void accepted(Project project, String email, String firstname, String lastname){
        String subject = "Successfully added to " + project.getName();
        String message = "Dear " + firstname + " " + lastname + ",\n\n"
                + "You have been successfully added to " + project.getName() + ".\n"
                + "You are now a collaborator and now have an editor role\n"
                + "Kindly note that you are now a registered user in the " +
                "web application and can login and edit your user profile in addition. \n\n"
                + "Best regards,\n"
                + "Project Team";
        sendEmail(subject, email, message);
    }

    public void accepted(Project project, String email, String username){
        String subject = "Successfully added to " + project.getName();
        String message = "Dear " + username + ",\n\n"
                + "You have been successfully added to " + project.getName() + ".\n"
                + "You are now a collaborator and now have an editor role\n"
                + "Kindly note that you are now a registered user in the " +
                "web application and can login and edit your user profile in addition. \n\n"
                + "Best regards,\n"
                + "Project Team";
        sendEmail(subject, email, message);
    }

    public Object getCollaboratorsByCode(String code){
        List<Profile> collabs = projectRepository.findByCode(code).orElseThrow().getCollaborators().stream().toList();
        List<AllCollaboratorsResponse> collab = new ArrayList<>();
        for (Profile profile : collabs){
            AllCollaboratorsResponse response = new AllCollaboratorsResponse();
            response.setFirstName(profile.getFirstName());
            response.setLastName(profile.getLastName());
            response.setOtherNames(profile.getOtherNames());
            response.setBio(profile.getBio());
            response.setOrganization(profile.getOrganization());
            response.setUsername(profile.getUsername());

            collab.add(response);

        }
        return collab;
    }


}

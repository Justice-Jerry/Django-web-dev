package com.rafce.rafce.model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

@Document(collection = "threats")
@AllArgsConstructor
@NoArgsConstructor
@Data
public class Threats {
    @Id
    private String id;
    private String title;
    private String content;
}

package com.rafce.rafce.model;

import java.time.LocalDateTime;
import java.util.*;


import lombok.*;
import org.bson.types.ObjectId;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.DBRef;
import org.springframework.data.mongodb.core.mapping.Document;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;


import java.util.HashSet;
import java.util.stream.Collectors;

@Document(collection = "profiles")
@AllArgsConstructor
@NoArgsConstructor
@Data
public class Profile implements UserDetails {

    //Let's use these now
    @Id
    private String id;
    private String firstName;
    private String lastName;
    private String bio;
    private String organization;
    private String otherNames;
    public String country;
    public String state;
    public String city;
    public String street;
    private String username;
    private String email;
//    private Boolean is_admin;
//    private Boolean is_pi;

    private String password;


    //password reset

    private String token;

    public String getToken() {
        return token;
    }

//    private String passwordResetToken;

//    public String getPasswordResetToken() {
//        return passwordResetToken;
//    }

//    public void setPasswordResetToken(String passwordResetToken) {
//        this.passwordResetToken = passwordResetToken;
//    }

    //private String newPassword;


    @DBRef
    private Set<Role> roles = new HashSet<>();

    private Collection<? extends GrantedAuthority> authorities;


    public Profile(String username, String email, String password) {
        this.username = username;
        this.email = email;
        this.password = password;
    }

    public Profile(String username, String email, String encode, String firstName, String lastName, String otherNames, String bio, String organization) {
        this.username = username;
        this.email = email;
        this.password = encode;
        this.firstName = firstName;
        this.lastName = lastName;
        this.otherNames = otherNames;
        this.bio = bio;
        this.organization = organization;
    }

    public Profile(String username, String email, String encode, String firstName, String lastName, String otherNames, String country, String state, String city, String street, String bio, String organization) {
        this.username = username;
        this.email = email;
        this.password = encode;
        this.firstName = firstName;
        this.lastName = lastName;
        this.otherNames = otherNames;
        this.country = country;
        this.state = state;
        this.city = city;
        this.street = street;
        this.bio = bio;
        this.organization = organization;
    }

//    public Profile(String passwordResetToken) {
//        this.passwordResetToken = passwordResetToken;
//   }

    @Override
    public Collection<? extends GrantedAuthority> getAuthorities() {
        return roles.stream()
                .map(role -> new SimpleGrantedAuthority(role.getName().name()))
                .collect(Collectors.toList());
    }

    @Override
    public String getPassword() {
        return password;
    }

//    public String passwordResetToken(){ return passwordResetToken;}

    @Override
    public String getUsername() {
        return username;
    }

    @Override
    public boolean isAccountNonExpired() {
        return true;
    }

    @Override
    public boolean isAccountNonLocked() {
        return true;
    }

    @Override
    public boolean isCredentialsNonExpired() {
        return true;
    }

    @Override
    public boolean isEnabled() {
        return true;
    }
}

package com.rafce.rafce.service;


import com.rafce.rafce.model.Hazard;
import com.rafce.rafce.payload.response.MessageResponse;
import com.rafce.rafce.repository.HazardRepository;
import lombok.AllArgsConstructor;
import lombok.NoArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.NoSuchElementException;

@Service
@AllArgsConstructor
@NoArgsConstructor
public class LockingService {

    @Autowired
    HazardRepository hazardRepository;

    public Object acquireLock( String entityID, String username, String type){
        return updateLockState(entityID, username, true, type);
    }
    public  Object releaseLock(String entityID, String type){
        return updateLockState(entityID, null, false, type);
    }
    public Object updateLockState(
                                       String entityID,
                                       String username,
                                       boolean isLocked,
                                       String type){
        if(type.equals("hazard")){
            Hazard hazard = hazardRepository.findById(entityID).orElseThrow(()-> new NoSuchElementException("No hazard with the id:" + entityID + " found"));
            if (hazard.isLocked() != isLocked ){
                hazard.setLocked(isLocked);
                hazard.setLockedByUserUsername(username);
                hazard.setLockAquiredAt(isLocked ? LocalDateTime.now() : null);
                hazardRepository.save(hazard);
                return ResponseEntity.ok(new MessageResponse(("Success")));
            }
            return ResponseEntity.status(HttpStatus.CONFLICT).body("Hazard is currrently being edited by user: " + hazard.getLockedByUserUsername());
        }
        return false;
    }
}

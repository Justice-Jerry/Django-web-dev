package com.rafce.rafce.model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.geo.GeoJsonPoint;
import org.springframework.data.mongodb.core.mapping.DBRef;
import org.springframework.data.mongodb.core.mapping.Document;

import java.time.LocalDate;
import java.util.Date;
import java.util.HashSet;
import java.util.Set;

@Document(collection = "projects")
@AllArgsConstructor
@NoArgsConstructor
@Data
public class Project {
    @Id
    private String id;

    private String code;

    private String name;
    private String description;




    private GeoJsonPoint location;

    @DBRef
    private Profile creator;
//
    @DBRef
    private Set<Profile> collaborators = new HashSet<>();
//
//    @DBRef
//    private Set<Hazard> hazards = new HashSet<>();

    private LocalDate createdAt;


    public Project(String name, String description, String code) {
        this.name = name;
        this.description = description;
        this.code = code;
    }

    public Project(String name, String description, double longitude, double latitude) {
        this.name = name;
        this.description = description;
    }
}

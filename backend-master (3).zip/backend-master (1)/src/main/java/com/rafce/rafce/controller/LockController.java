package com.rafce.rafce.controller;

import com.rafce.rafce.service.LockingService;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.bind.annotation.*;

@CrossOrigin(origins = "*", maxAge = 3600)
@RestController
@RequestMapping("/api/v1/lock")
@RequiredArgsConstructor
@PreAuthorize("hasRole('ROLE_US') or hasRole('ROLE_PI') or hasRole('ROLE_ADMIN')")
public class LockController {
    @Autowired
    LockingService lockingService;

    @PostMapping("acquire-lock/{id}")
    public Object acquireLock(@PathVariable String id){
        Authentication auth = SecurityContextHolder.getContext().getAuthentication();
        String username = auth.getName();

        return lockingService.acquireLock(id, username, "hazard");
    }



}

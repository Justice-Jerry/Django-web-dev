package com.rafce.rafce.payload.request;


import com.rafce.rafce.model.Project;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Set;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class AcceptInviteRequest {

    private String username;

    private String password;

    private String bio;
    private String otherNames;

}

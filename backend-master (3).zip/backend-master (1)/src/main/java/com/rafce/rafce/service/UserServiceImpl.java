//package com.rafce.rafce.service;
//
//import com.rafce.rafce.model.Profile;
//import com.rafce.rafce.repository.ProfileRepository;
//import com.rafce.rafce.repository.UserService;
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.stereotype.Service;
//
//import java.util.Optional;
//
//@Service("userService")
//public class UserServiceImpl implements UserService {
//    @Autowired
//    private ProfileRepository profileRepository;
//
//    @Override
//    public Optional findByUserEmail(String email) {
//        return profileRepository.findByEmail(email);
//    }
//
//    @Override
//    public Optional findByResetToken(String resetToken) {
//        return profileRepository.findByToken(resetToken);
//    }
//
//    @Override
//    public void save(Profile user) {
//        profileRepository.save(user);
//    }
//}

//package com.rafce.rafce.model;
//
//import org.springframework.data.annotation.Id;
//
//import java.io.Serializable;
//import javax.persistence.Entity;
//import javax.persistence.GeneratedValue;
//import javax.persistence.JoinColumn;
//import javax.persistence.OneToOne;
//
//@Entity(name = "password_reset_tokens")
//public class PasswordResetToken implements Serializable {
//
//    private static final long serialVersionUID = 5754050793264003036L;
//
//    @Id
//    @GeneratedValue
//    private long id;
//
//    private String token;
//
//    @OneToOne()
//    @JoinColumn(name = "users_id")
//    private Profile userDetails;
//
//    public long getId() {
//        return id;
//    }
//
//    public void setId(long id) {
//        this.id = id;
//    }
//
//    public String getToken() {
//        return token;
//    }
//
//    public void setToken(String token) {
//        this.token = token;
//    }
//
//    public Profile getUserDetails() {
//        return userDetails;
//    }
//
//    public void setUserDetails(Profile userDetails) {
//        this.userDetails = userDetails;
//    }
//}

package com.rafce.rafce.model;

import org.springframework.data.annotation.Id;

public class Location {
    @Id
    private String id;
    private Double[] position;
}

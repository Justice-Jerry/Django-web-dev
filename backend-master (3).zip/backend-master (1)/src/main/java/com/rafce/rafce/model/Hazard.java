package com.rafce.rafce.model;


import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import java.time.LocalDate;
import java.time.LocalDateTime;

@Document(collection = "hazards")
@AllArgsConstructor
@NoArgsConstructor
@Data
public class Hazard {
    @Id
    private String id;
    private String title;
    private String content;
    private boolean isLocked;
    private String lockedByUserUsername;
    private LocalDateTime lockAquiredAt;
    private long version;
    private String projectCode;
}

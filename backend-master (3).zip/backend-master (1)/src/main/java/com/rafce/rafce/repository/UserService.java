//package com.rafce.rafce.repository;
//
//import com.rafce.rafce.model.Profile;
//
//import java.util.Optional;
//
//public interface UserService {
//    public Optional <Profile> findByUserEmail(String email);
//    public Optional <Profile> findByResetToken(String resetToken);
//    public void save(Profile user);
//}

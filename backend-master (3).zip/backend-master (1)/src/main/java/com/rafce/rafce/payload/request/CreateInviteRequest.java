package com.rafce.rafce.payload.request;


import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class CreateInviteRequest {

    private String projectCode;

    private String firstName;

    private String lastName;

    private String organization;

    private String email;

}

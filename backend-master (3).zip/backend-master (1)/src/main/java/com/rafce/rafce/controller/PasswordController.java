//package com.rafce.rafce.controller;
//
//import com.rafce.rafce.model.Profile;
//import com.rafce.rafce.repository.ProfileRepository;
//import com.rafce.rafce.service.ProfileService;
//import jakarta.servlet.http.HttpServletRequest;
//import lombok.RequiredArgsConstructor;
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
//import org.springframework.web.bind.MissingServletRequestParameterException;
//import org.springframework.web.bind.annotation.*;
//import org.springframework.web.servlet.ModelAndView;
//import org.springframework.web.servlet.mvc.support.RedirectAttributes;
//
//import java.util.Map;
//import java.util.UUID;
//
//@CrossOrigin(origins = "*", maxAge = 3600)
//@RestController
//@RequestMapping("/api/v1/user")
//@RequiredArgsConstructor
//
//public class PasswordController {
//
//    @Autowired
//    ProfileService profileService;
//
//    @Autowired
//    ProfileRepository profileRepository;
//
//    @Autowired
//    private BCryptPasswordEncoder bCryptPasswordEncoder;
//
//    @GetMapping("/forgot")
//    public ModelAndView displayPasswordResetPage(){
//        return new ModelAndView("forgot password");
//    }
//
//    @PostMapping("/forgot")
//    public ModelAndView processPasswordResetForm(ModelAndView modelAndView, @RequestBody String userEmail, HttpServletRequest request){
//        Profile profile = (Profile) profileRepository.findByEmail(userEmail).orElseThrow();
//
////        if(!profile.isPresent()){
////            modelAndView.addObject("errorMessage", "We didn't find an account for the given email address.");
////        }else{
//        ((Profile) profile).setToken(UUID.randomUUID().toString());
//
//            profileRepository.save(profile);
//
//            String appUrl = request.getScheme() + "://" + request.getServerName();
//
//            String subject = "Password Reset on RAFCEGH";
//            String message = "\n\n" +
//                    "You're receiving this e-mail because you requested for a password reset for your account at RAFCEGH.\n" +
//                    "if you didn't request this change, you can disregard this email, we have not yet reset your password:\n" +
//                    "Please click on the link below to reset your password:" +
//                    "Please click on the link below to reset your password:\n" +
//                    //"http://localhost:8080/reset-password?token=" + user.getPasswordResetToken()+
//                    appUrl + ((Profile) profile).getToken()+
//                    "\n\nBest regards,\n" +
//                    "Project Team"
//                    ;
//
//            profileService.sendPasswordResetEmail(subject, userEmail, message);
//
//            modelAndView.addObject("successMessage", "A password reset link has been sent to " + userEmail);
////        }
//        modelAndView.setViewName("forgotPassword");
//        return modelAndView;
//    }
//
//    @GetMapping("/reset")
//    public ModelAndView displayPasswordResetPage(ModelAndView modelAndView, @RequestParam("token") String token){
//        Profile user = (Profile) profileRepository.findByToken(token).orElseThrow();
//
////        if(user.isPresent()){
//          modelAndView.addObject("resetToken", token);
////        }
////        else {
////            modelAndView.addObject("error message", "Oops! This is an invalid password reset link.");
//        //}
//        modelAndView.setViewName("resetPassword");
//        return modelAndView;
//    }
//
//    @PostMapping("/reset")
//    public ModelAndView setNewPassword(ModelAndView modelAndView, @RequestParam Map<String, String> requestParams, RedirectAttributes redir) {
//        Profile user = (Profile) profileRepository.findByToken(requestParams.get("token")).orElseThrow();
////        if(user.isPresent()){
//
//        user.setPassword(bCryptPasswordEncoder.encode(requestParams.get("password")));
//            ((Profile) user).setToken(null);
//            profileService.saveUser((Profile) user);
//
//            redir.addFlashAttribute("successMessage", "You have successfully reset your password. You may continue to login.");
//            modelAndView.setViewName("redirect:login");
//            return modelAndView;
////        }
////        else{
////            modelAndView.addObject("error message", "Oops! This is an invalid password reset link.");
////            modelAndView.setViewName("resetPassword");
////        }
////        return modelAndView;
//    }
//    @ExceptionHandler(MissingServletRequestParameterException.class)
//    public ModelAndView handleMissingParams(MissingServletRequestParameterException ex){
//        return new ModelAndView("redirect: login");
//    }
//}
package com.rafce.rafce.service;

import com.rafce.rafce.model.Hazard;
import com.rafce.rafce.model.Profile;
import com.rafce.rafce.model.Project;
import com.rafce.rafce.payload.response.MessageResponse;
import com.rafce.rafce.repository.HazardRepository;
import com.rafce.rafce.repository.ProfileRepository;
import com.rafce.rafce.repository.ProjectRepository;
import lombok.AllArgsConstructor;
import lombok.NoArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Service;

import java.util.NoSuchElementException;
import java.util.Set;

@Service
@AllArgsConstructor
@NoArgsConstructor
public class HazardService {
    @Autowired
    HazardRepository hazardRepository;

    @Autowired
    ProjectRepository projectRepository;

    @Autowired
    ProfileRepository profileRepository;

    @Autowired
    LockingService lockingService;



    public void updateHazard(String title, String content, String projectCode, String id) {
        Project project = projectRepository.findByCode(projectCode).orElseThrow(() -> new NoSuchElementException("Invitation with id " + id + " not found"));

        Set<Profile> collaborators = project.getCollaborators();

        Authentication auth = SecurityContextHolder.getContext().getAuthentication();
        String username = auth.getName();
        Profile profile = profileRepository.findByUsername(username).orElseThrow(() -> new NoSuchElementException("Username:" + username + " not found"));
        if (!collaborators.contains(profile) && profile == project.getCreator()) {
            ResponseEntity.status(HttpStatus.FORBIDDEN).body("You do not have permission to edit this document");
            return;
        }

        Hazard hazard = hazardRepository.findById(id).orElseThrow();
        if (hazard.isLocked() && !username.equals(hazard.getLockedByUserUsername())) {
            ResponseEntity.status(HttpStatus.CONFLICT).body("Lock Acquired by: " + hazard.getLockedByUserUsername());
        }
        hazard.setTitle(title);
        hazard.setContent(content);
        hazardRepository.save(hazard);
        ResponseEntity.ok(new MessageResponse(("Updated Successfully")));
//        lockingService.releaseLock(id, "hazard");
    }
}

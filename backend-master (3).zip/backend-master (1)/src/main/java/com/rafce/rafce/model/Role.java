package com.rafce.rafce.model;


import com.mongodb.client.model.ClusteredIndexOptions;
import lombok.*;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

@Document(collection = "roles")
@AllArgsConstructor
@NoArgsConstructor
@Data
public class Role {
    @Id
    private String id;
    private ERole name;

}

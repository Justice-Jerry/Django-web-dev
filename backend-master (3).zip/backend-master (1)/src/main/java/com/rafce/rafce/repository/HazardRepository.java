package com.rafce.rafce.repository;

import com.rafce.rafce.model.Hazard;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;


@Repository
public interface HazardRepository extends MongoRepository<Hazard, String> {
    Optional<Hazard> findById(String s);

}

package com.rafce.rafce.service;

import com.rafce.rafce.authService.AuthResponse;
import com.rafce.rafce.config.JwtService;
import com.rafce.rafce.model.*;
import com.rafce.rafce.payload.response.MessageResponse;
import com.rafce.rafce.repository.*;
import lombok.AllArgsConstructor;
import lombok.NoArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import java.time.Duration;
import java.time.LocalDateTime;
import java.util.*;

@Service
@AllArgsConstructor
@NoArgsConstructor
public class ProfileService {
    @Autowired
    PasswordEncoder encoder;


    @Autowired
    JwtService jwtService;


    @Autowired
    AuthenticationManager authmanager;

    @Autowired
    InvitationRepository invitationRepository;

    @Autowired
    ProjectRepository projectRepository;

    @Autowired
    BCryptPasswordEncoder bCryptPasswordEncoder;

    @Autowired
    ProfileRepository profileRepository;

    @Autowired
    RoleRepository roleRepository;

    @Autowired
    ProjectService projectService;

    @Autowired
    JavaMailSender javaMailSender;

    @Autowired
    PasswordResetRepository passwordResetRepository;

    public Object acceptInvite(String username, String id, String password, String otherNames, String bio){
        if(profileRepository.existsByUsername(username)){
            return ResponseEntity
                    .badRequest()
                    .body(new MessageResponse("Username taken"));
        }

        Invitation invite = invitationRepository.findById(id).orElseThrow(() -> new NoSuchElementException("Invitation with id " + id + " not found"));
        Project project = projectRepository.findByCode(invite.getProjectCode()).orElseThrow();

        Set<Profile> collaborators = project.getCollaborators();
        Set<Role> roles = new HashSet<>();
        Role userRole = roleRepository.findByName(ERole.ROLE_US)
                .orElseThrow(() -> new RuntimeException("Error: Role is not found."));
        roles.add(userRole);

        Profile profile = new Profile(
                username,
                invite.getEmail(),
                encoder.encode(password),
                invite.getFirstName(),
                invite.getLastName(),
                otherNames,
                bio,
                invite.getOrganization()
        );

        profile.setRoles(roles);

        if (collaborators.contains(profile)){
            return ResponseEntity
                    .badRequest()
                    .body(new MessageResponse("User already in project"));
        }
        collaborators.add(profile);
        project.setCollaborators(collaborators);

        profileRepository.save(profile);
        projectRepository.save(project);


        var jwtToken = jwtService.generateToken(profile);
        projectService.accepted(project, invite.getEmail(), invite.getFirstName(), invite.getLastName());
        return AuthResponse
                .builder()
                .token(jwtToken)
                .message("Successfully added to project")
                .build();
    }
    public Object registerUser(
            String username,
            String email,
            String password,
            String firstName,
            String lastName,
            String otherNames,
            String country,
            String state,
            String city,
            String street,
            String bio,
            String organization,
            Set<String> strRoles){
        if(username == null){
            return ResponseEntity
                    .badRequest()
                    .body(new MessageResponse("Username field empty"));
        }
        if (profileRepository.existsByUsername(username)) {
            return ResponseEntity
                    .badRequest()
                    .body(new MessageResponse("Error: Username is already taken!"));
        }

        if (profileRepository.existsByEmail(email)) {
            return ResponseEntity
                    .badRequest()
                    .body(new MessageResponse("Error: Email is already in use!"));
        }

        Profile profile = new Profile(username,
                email,
                encoder.encode(password),
                firstName,
                lastName,
                otherNames,
                country,
                state,
                city,
                street,
                bio,
                organization);

        Set<Role> roles = new HashSet<>();

        if (strRoles == null) {
            Role userRole = roleRepository.findByName(ERole.ROLE_US)
                    .orElseThrow(() -> new RuntimeException("Error: Role is not found."));
            roles.add(userRole);
        } else {
            strRoles.forEach(role -> {
                switch (role) {
                    case "admin" -> {
                        Role adminRole = roleRepository.findByName(ERole.ROLE_ADMIN)
                                .orElseThrow(() -> new RuntimeException("Error: Role is not found."));
                        roles.add(adminRole);
                    }
                    case "pi" -> {
                        Role modRole = roleRepository.findByName(ERole.ROLE_PI)
                                .orElseThrow(() -> new RuntimeException("Error: Role is not found."));
                        roles.add(modRole);
                    }
                    default -> {
                        Role userRole = roleRepository.findByName(ERole.ROLE_US)
                                .orElseThrow(() -> new RuntimeException("Error: Role is not found."));
                        roles.add(userRole);
                    }
                }
            });
        }

        profile.setRoles(roles);
        profileRepository.save(profile);


        var jwtToken = jwtService.generateToken(profile);
        return AuthResponse
                .builder()
                .token(jwtToken)
                .message("Signup successful")
                .build();

    }
    public Object authenticate(String username, String password){
        Authentication auth = authmanager.authenticate(new UsernamePasswordAuthenticationToken(
                username,
                password));

        SecurityContextHolder.getContext().setAuthentication(auth);
        UserDetails user = (UserDetails) auth.getPrincipal();
        String jwt = jwtService.generateToken(user);

        return AuthResponse
                .builder()
                .token(jwt)
                .message("Login successful")
                .build();
    }
    public Object userAcceptInvitation(String username,String id, String password){
        Invitation invite = invitationRepository.findById(id).orElseThrow(() -> new NoSuchElementException("Invitation with id " + id + " not found"));
        Project project = projectRepository.findByCode(invite.getProjectCode()).orElseThrow();
        Authentication auth = authmanager.authenticate(new UsernamePasswordAuthenticationToken(
                username,
                password));

        SecurityContextHolder.getContext().setAuthentication(auth);
        UserDetails user = (UserDetails) auth.getPrincipal();



        Set<Profile> collaborators = project.getCollaborators();

        if (collaborators.contains((Profile) user)){
            return ResponseEntity
                    .badRequest()
                    .body(new MessageResponse("User already in project"));
        }
        collaborators.add((Profile) user);
        project.setCollaborators(collaborators);
        projectRepository.save(project);


        String jwt = jwtService.generateToken(user);
        projectService.accepted(project, invite.getEmail(), username);
        return AuthResponse
                .builder()
                .token(jwt)
                .message("Successfully added to project")
                .build();
    }

    public void sendPasswordResetEmail(String subject, String email, String message){
        SimpleMailMessage mailMessage = new SimpleMailMessage();
        mailMessage.setTo(email);
        mailMessage.setSubject(subject);
        mailMessage.setFrom("RAFCEGH");
        mailMessage.setText(message);


        javaMailSender.send(mailMessage);
    }

        // password reset
        public String passwordReset(String email){
            Password request = new Password();
            request.setEmail(email);
            passwordResetRepository.save(request);

            request.setToken(UUID.randomUUID().toString());

            String subject = "Password Reset on RAFCEGH";
            String message = "\n\n" +
                    "You're receiving this e-mail because you requested for a password reset for your account at RAFCEGH.\n" +
                    "if you didn't request this change, you can disregard this email, we have not yet reset your password:\n" +
                    "Please click on the link below to reset your password:" +
                    "Please click on the link below to reset your password:\n" +
                    "http://localhost:8080/reset-password?token=" + request.getToken()+
                    "\nBest regards,\n" +
                    "Project Team"
                    ;

            sendPasswordResetEmail(subject, request.getEmail(), message);
            request.setToken(null);

            return "Email sent";
    }

    public void changePassword(String email, String newPassword){
        Profile user = profileRepository.findByEmail(String.valueOf(email)).orElseThrow();
        user.setPassword(bCryptPasswordEncoder.encode(newPassword));
        profileRepository.save(user);
    }
}



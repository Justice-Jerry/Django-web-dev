package com.rafce.rafce.controller;


import com.rafce.rafce.config.JwtService;
import com.rafce.rafce.model.Profile;
import com.rafce.rafce.model.Project;;
import com.rafce.rafce.payload.request.AddToProjectRequest;
import com.rafce.rafce.payload.request.CreateInviteRequest;
import com.rafce.rafce.payload.request.CreateProjectRequest;
import com.rafce.rafce.payload.response.AllProjectsResponse;
import com.rafce.rafce.payload.response.MessageResponse;
import com.rafce.rafce.payload.response.ResponseHandler;
import com.rafce.rafce.repository.ProfileRepository;
import com.rafce.rafce.repository.ProjectRepository;
import com.rafce.rafce.service.ProjectService;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.geo.GeoJsonPoint;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;

@CrossOrigin(origins = "*", maxAge = 3600)
@RestController
@RequestMapping("/api/v1/projects")
@RequiredArgsConstructor
@PreAuthorize("hasRole('ROLE_PI')")
public class ProjectController {
    @Autowired
    JwtService jwtService;

    @Autowired
    ProjectRepository projectRepository;

    @Autowired
    ProfileRepository profileRepository;

    @Autowired
    ProjectService projectService;

    @GetMapping("/all-projects")
    public Object Projects(){
        Authentication auth = SecurityContextHolder.getContext().getAuthentication();
        String username = auth.getName();
        Profile creator = profileRepository.findByUsername(username).orElseThrow();
        List<Project> projectCreatedByPI = projectService.getProjectCreatedByPi(creator);
        List<AllProjectsResponse> responses = new ArrayList<>();
        for(Project project : projectCreatedByPI){
            AllProjectsResponse allProjectsResponse = new AllProjectsResponse();
            allProjectsResponse.setCode(project.getCode());
            allProjectsResponse.setId(project.getId());
            allProjectsResponse.setCreator(project.getCreator().getUsername());
            allProjectsResponse.setName(project.getName());
            allProjectsResponse.setLocation(project.getLocation());
            allProjectsResponse.setDescription(project.getDescription());
            allProjectsResponse.setCreatedAt(project.getCreatedAt());

            responses.add(allProjectsResponse);
            }
        return responses;
    }
    @GetMapping("/all-collaborators/{code}")
    public Object viewAllCollaborators(@PathVariable String code){
        return projectService.getCollaboratorsByCode(code);
    }
    @PostMapping("/create-project")
    public Object CreateProject(@RequestBody CreateProjectRequest projectRequest){
        if(projectRepository.existsByCode(projectRequest.getCode())){
            return ResponseEntity
                    .badRequest()
                    .body(new MessageResponse("Project code taken! Enter another unique code"));
        }

        Authentication auth = SecurityContextHolder.getContext().getAuthentication();
        String username = auth.getName();
        Profile user = profileRepository
                .findByUsername(username)
                .orElseThrow(() -> new RuntimeException("User not found"));


        double latitude =  projectRequest.getLatitude();
        double longitude = projectRequest.getLongitude();
        GeoJsonPoint location = new GeoJsonPoint(longitude, latitude);
        Project project = new Project();


        LocalDate date = LocalDate.now();
        project.setName(projectRequest.getName());
        project.setDescription(projectRequest.getDescription());
        project.setCode(projectRequest.getCode());
        project.setCreatedAt(date);
        project.setCreator(user);
        project.setLocation(location);
        projectRepository.save(project);
        return ResponseEntity.ok(new MessageResponse("Project created"));
    }

    @PostMapping("/send-invite")
    public Object sendInvite(@RequestBody  CreateInviteRequest request){
        if(request.getProjectCode()  == null){
            return ResponseEntity
                    .badRequest()
                    .body(new MessageResponse("Add a project code request"));
        }
        if(!projectRepository.existsByCode(request.getProjectCode())){
            return ResponseEntity
                    .badRequest()
                    .body(new MessageResponse("Project doesn't exist!"));
        }

        Project project = projectRepository
                .findByCode(request.getProjectCode())
                .orElseThrow(()-> new RuntimeException("Project not found"));

        String email = request.getEmail();
        if(!profileRepository.existsByEmail(email)){
            String inviteID = projectService.sendInvite(project, request.getEmail(), request.getFirstName(), request.getLastName(), request.getProjectCode(), request.getOrganization());
            return ResponseEntity.ok(new MessageResponse(inviteID));
        }
        Profile profile = profileRepository.findByEmail(email).orElseThrow();
        String inviteID  = projectService.sendInvite(project, profile.getEmail(), profile.getUsername(), request.getProjectCode());
        return ResponseEntity.ok(new MessageResponse(inviteID));
    }

    @PostMapping("/add")
    public Object addUser(@RequestBody AddToProjectRequest request){
        if (!profileRepository.existsByUsername(request.getUsername())){
            return ResponseEntity
                    .badRequest()
                    .body(new MessageResponse("Cannot add unknown user"));
        }
        Profile profile = profileRepository.findByUsername(request.getUsername()).orElseThrow(()-> new RuntimeException("Project not found"));
        Project project = projectRepository.findByCode(request.getProjectCode()).orElseThrow(()-> new RuntimeException("Project not found"));
        Set<Profile> collaborators = project.getCollaborators();

        if (collaborators.contains(profile)){
            return ResponseEntity
                    .badRequest()
                    .body(new MessageResponse("User already in project"));
        }
        collaborators.add(profile);
        project.setCollaborators(collaborators);
        projectRepository.save(project);
        return ResponseEntity.ok(new MessageResponse("Successfully added to project!"));
    }
}
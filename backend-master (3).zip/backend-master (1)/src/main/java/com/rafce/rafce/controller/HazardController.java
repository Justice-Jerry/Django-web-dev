package com.rafce.rafce.controller;


import com.rafce.rafce.service.HazardService;
import com.rafce.rafce.service.LockingService;
import lombok.Data;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

@CrossOrigin(origins = "*", maxAge = 3600)
@RestController
@RequestMapping("/api/v1/hazard")
@RequiredArgsConstructor
@PreAuthorize("hasRole('ROLE_US') or hasRole('ROLE_PI') or hasRole('ROLE_ADMIN')")
public class HazardController {

    @Data
    static class HazardUpdateRequest{
        String title;
        String content;
        String prokectCode;

    }

    @Autowired
    HazardService hazardService;

    @Autowired
    LockingService lockingService;

    @PostMapping
    public void createHazard(){

    }
    @PostMapping("/update/{id}")
    public Object updateHazard(@RequestBody HazardUpdateRequest request, @PathVariable String id) {
        hazardService.updateHazard(request.getTitle(), request.getContent(), request.getProkectCode(), id);
        return lockingService.releaseLock(id, "hazard");
    }
}

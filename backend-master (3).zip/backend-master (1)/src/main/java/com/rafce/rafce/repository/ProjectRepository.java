package com.rafce.rafce.repository;


import com.rafce.rafce.model.Profile;
import com.rafce.rafce.model.Project;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;
import java.util.Set;


@Repository
public interface ProjectRepository extends MongoRepository<Project, String> {
    Optional<Project> findByCode(String s);

    List<Project>findByCreator(Profile creator);



    Boolean existsByCode(String code);

//    boolean existsById(String id);
}

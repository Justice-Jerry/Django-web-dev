package com.rafce.rafce.payload.response;


import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class AllCollaboratorsResponse {

    private String firstName;
    private String lastName;

    private String otherNames;

    private String bio;
    private String email;
    private String organization;

    private String username;

}

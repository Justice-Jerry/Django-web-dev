package com.rafce.rafce.payload.request;


import lombok.*;

import java.util.Set;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class SignupRequest {
    private String username;
    private String email;
    private Set<String> roles;

    private String password;

    private String firstName;
    private String lastName;
    private String bio;
    private String organization;
    private String otherNames;
    private String country;
    private String state;
    private String city;
    private String street;
}

package com.rafce.rafce.repository;

import com.rafce.rafce.model.TopEvents;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.data.mongodb.core.mapping.Document;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface TopEventRepository extends MongoRepository<TopEvents, String> {
}

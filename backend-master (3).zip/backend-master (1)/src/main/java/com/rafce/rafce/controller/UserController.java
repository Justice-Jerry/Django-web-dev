package com.rafce.rafce.controller;

import com.rafce.rafce.model.Password;
import com.rafce.rafce.model.Profile;
import com.rafce.rafce.payload.request.*;
import com.rafce.rafce.repository.PasswordResetRepository;
import com.rafce.rafce.repository.ProfileRepository;
import com.rafce.rafce.service.ProfileService;
import com.rafce.rafce.service.ProjectService;
import jakarta.servlet.http.HttpServletRequest;
import lombok.RequiredArgsConstructor;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.web.bind.MissingServletRequestParameterException;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import java.util.Map;
import java.util.UUID;


@CrossOrigin(origins = "*", maxAge = 3600)
@RestController
@RequestMapping("/api/v1/user")
@RequiredArgsConstructor
public class UserController {

    private static final Logger logger = LoggerFactory.getLogger(UserController.class);
//    @Autowired
//    AuthService authService;

    @Autowired
    ProfileService profileService;
    @Autowired
    ProfileRepository profileRepository;

    @Autowired
    private BCryptPasswordEncoder bCryptPasswordEncoder;

    @Autowired
    PasswordResetRepository passwordResetRepository;

    @Autowired
    ProjectService projectService;

    @GetMapping
    public String SayWelcomw(){
        return "Welcome";
    }



    @PostMapping("/authenticate")
    public Object authenticateUser(@RequestBody LoginRequest request) {
        return profileService.authenticate(
                request.getUsername(),
                request.getPassword());
    }

    @PostMapping (value = "/accept/{id}")
    public Object acceptInvite(@RequestBody() AcceptInviteRequest request,  @PathVariable String id){
        return profileService.acceptInvite(
                request.getUsername(),
                id,
                request.getPassword(),
                request.getOtherNames(),
                request.getBio());
    }

    @PostMapping (value = "/user-accept/{id}")
    public Object userAcceptInvite(@RequestBody()AcceptInviteExistingUserRequest request, @PathVariable String id){
        return profileService.userAcceptInvitation(
                request.getUsername(),
                id,
                request.getPassword());
    }

    @PostMapping("/signup")
    public Object registerUser(@RequestBody SignupRequest request) {
        return profileService.registerUser(
                request.getUsername(),
                request.getEmail(),
                request.getPassword(),
                request.getFirstName(),
                request.getLastName(),
                request.getOtherNames(),
                request.getCountry(),
                request.getState(),
                request.getCity(),
                request.getStreet(),
                request.getBio(),
                request.getOrganization(),
                request.getRoles());
    }


    @PostMapping("/forgot")
    public String resetPassword(@RequestBody PasswordResetRequest email) {
       return profileService.passwordReset(email.getEmail());
    }

    @PostMapping("/reset-password")
    public String resetPassword(@RequestBody String email,
                                @RequestBody String newPassword) {
    profileService.changePassword(email, newPassword);
    return "Password changed successfully";
    }

}

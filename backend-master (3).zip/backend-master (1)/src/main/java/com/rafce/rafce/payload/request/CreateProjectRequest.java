package com.rafce.rafce.payload.request;

import com.rafce.rafce.model.Profile;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDate;
import java.util.Date;
import java.util.Set;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class CreateProjectRequest {

    private String name;

    private String description;

    private String creator;

    private Set<String> collaborators;

    private LocalDate CreatedAt;


    private double longitude;

    private double latitude;

    private String code;


}

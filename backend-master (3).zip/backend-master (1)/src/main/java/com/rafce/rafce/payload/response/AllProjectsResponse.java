package com.rafce.rafce.payload.response;


import com.rafce.rafce.model.Profile;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDate;
import java.util.Date;
import java.util.Set;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class AllProjectsResponse {
    private String id;

    private String name;

    private String code;

    private String description;

    private Object location;

    private String creator;

    private LocalDate createdAt;



}

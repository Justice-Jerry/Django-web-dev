package com.rafce.rafce.payload.response;

import lombok.*;
import org.bson.types.ObjectId;

import java.util.List;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class UserInfoResponse {
    private String id;
    private String username;
    private String email;
    private List<String> roles;

    private String FirstName;
    private String LastName;
    private String Bio;
    private String Organization;
    private String OtherNames;
}
